package data;

// Holds the full output after an algorithm finishes running.
// Passed from the algorithm to the GUI for display.
public class ScheduleResult {

    public GanttEntry[] gantt;      // The sequence of Gantt blocks to draw
    public int ganttSize;           // How many blocks are in the gantt array
    public Process[] processes;     // The completed processes with all times calculated
    public int processCount;        // How many processes are in the array

    public ScheduleResult(GanttEntry[] gantt, int ganttSize, Process[] processes, int processCount) {
        this.gantt        = gantt;
        this.ganttSize    = ganttSize;
        this.processes    = processes;
        this.processCount = processCount;
    }

    // Average Waiting Time across all processes
    public double getAverageWaitingTime() {
        double total = 0;
        for (int i = 0; i < processCount; i++) {
            total += processes[i].getWaitingTime();
        }
        return total / processCount;
    }

    // Average Turnaround Time across all processes
    public double getAverageTurnaroundTime() {
        double total = 0;
        for (int i = 0; i < processCount; i++) {
            total += processes[i].getTurnaroundTime();
        }
        return total / processCount;
    }

    // Average Response Time across all processes
    public double getAverageResponseTime() {
        double total = 0;
        for (int i = 0; i < processCount; i++) {
            total += processes[i].getResponseTime();
        }
        return total / processCount;
    }

    // Throughput = number of processes completed per unit of time
    public double getThroughput() {
        int firstArrival = processes[0].arrivalTime;
        int lastFinish   = processes[0].finishTime;

        for (int i = 1; i < processCount; i++) {
            if (processes[i].arrivalTime < firstArrival) firstArrival = processes[i].arrivalTime;
            if (processes[i].finishTime  > lastFinish)   lastFinish   = processes[i].finishTime;
        }

        int totalTime = lastFinish - firstArrival;
        if (totalTime == 0) return 0;
        return (double) processCount / totalTime;
    }
}

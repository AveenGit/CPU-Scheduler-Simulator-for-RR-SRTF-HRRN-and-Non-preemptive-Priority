package data;

// Represents one process entered by the user.
// Every scheduling algorithm uses this class.
public class Process {

    public String pid;          // Process name e.g. "P1", "P2"
    public int arrivalTime;     // Time the process enters the ready queue
    public int burstTime;       // Total CPU time this process needs
    public int priority;        // Lower number = higher priority (used by NP Priority only)

    public int remainingTime;   // Counts down from burstTime as the process runs (used by RR and SRTF)
    public int startTime;       // First moment this process gets the CPU
    public int finishTime;      // Moment this process fully completes
    public boolean started;     // Tracks whether startTime has been set yet

    // Constructor — called when user adds a new process
    public Process(String pid, int arrivalTime, int burstTime, int priority) {
        this.pid           = pid;
        this.arrivalTime   = arrivalTime;
        this.burstTime     = burstTime;
        this.priority      = priority;
        this.remainingTime = burstTime; // process hasn't run yet, so remaining = full burst
        this.startTime     = -1;        // -1 means "not started yet"
        this.finishTime    = 0;
        this.started       = false;
    }

    // Turnaround Time = total time from arrival until completion
    public int getTurnaroundTime() {
        return finishTime - arrivalTime;
    }

    // Waiting Time = time spent waiting in queue, not running
    public int getWaitingTime() {
        return getTurnaroundTime() - burstTime;
    }

    // Response Time = time from arrival until first CPU access
    public int getResponseTime() {
        return startTime - arrivalTime;
    }

    // Returns a fresh copy of this process with all values reset
    // Used so each algorithm starts with clean data every time
    public Process copy() {
        return new Process(pid, arrivalTime, burstTime, priority);
    }
}

package data;

// Represents one block in the Gantt chart.
// Example: P1 ran from time 0 to time 3 → GanttEntry("P1", 0, 3)
public class GanttEntry {

    public String pid;      // Which process ran during this block
    public int startTime;   // When this block started
    public int endTime;     // When this block ended

    public GanttEntry(String pid, int startTime, int endTime) {
        this.pid       = pid;
        this.startTime = startTime;
        this.endTime   = endTime;
    }
}


package algorithm;

import data.GanttEntry;
import data.Process;
import data.ScheduleResult;

// Shortest Remaining Time First (SRTF) — Preemptive
// At every tick, the CPU picks the process with the shortest remaining burst time.
// If a new process arrives with less remaining time than the current one, it takes over.
// Strength : Produces minimum average waiting time
// Weakness : Long processes can starve. Needs burst time known in advance.
public class SRTF {

    public static ScheduleResult run(Process[] original, int count) {

        // Work on copies so original data stays unchanged
        Process[] processes = new Process[count];
        for (int i = 0; i < count; i++) {
            processes[i] = original[i].copy();
        }

        GanttEntry[] gantt = new GanttEntry[500];
        int ganttSize = 0;

        boolean[] done  = new boolean[count];
        int currentTime = 0;
        int completed   = 0;

        String lastPid  = "";   // which process ran last tick (to merge consecutive blocks)
        int sliceStart  = 0;    // start of the current Gantt block

        // Start time = earliest arrival
        int minArrival = processes[0].arrivalTime;
        for (int i = 1; i < count; i++) {
            if (processes[i].arrivalTime < minArrival) minArrival = processes[i].arrivalTime;
        }
        currentTime = minArrival;

        while (completed < count) {

            // Find the arrived process with the shortest remaining time
            int shortest      = -1;
            int minRemaining  = Integer.MAX_VALUE;

            for (int i = 0; i < count; i++) {
                if (!done[i] && processes[i].arrivalTime <= currentTime) {
                    if (processes[i].remainingTime < minRemaining) {
                        minRemaining = processes[i].remainingTime;
                        shortest     = i;
                    }
                }
            }

            // No process available yet — CPU idle, move time forward
            if (shortest == -1) {
                if (!lastPid.isEmpty()) {
                    gantt[ganttSize++] = new GanttEntry(lastPid, sliceStart, currentTime);
                    lastPid = "";
                }
                currentTime++;
                continue;
            }

            Process p = processes[shortest];

            // Record start time the first time this process runs
            if (!p.started) {
                p.startTime = currentTime;
                p.started   = true;
            }

            // If the running process changed, save the previous Gantt block
            if (!p.pid.equals(lastPid)) {
                if (!lastPid.isEmpty()) {
                    gantt[ganttSize++] = new GanttEntry(lastPid, sliceStart, currentTime);
                }
                lastPid    = p.pid;
                sliceStart = currentTime;
            }

            // Run one tick — SRTF checks every single time unit for preemption
            p.remainingTime--;
            currentTime++;

            // Check if the process just finished
            if (p.remainingTime == 0) {
                p.finishTime = currentTime;
                done[shortest] = true;
                completed++;

                // Save the final Gantt block for this process
                gantt[ganttSize++] = new GanttEntry(p.pid, sliceStart, currentTime);
                lastPid = "";
            }
        }

        return new ScheduleResult(gantt, ganttSize, processes, count);
    }
}
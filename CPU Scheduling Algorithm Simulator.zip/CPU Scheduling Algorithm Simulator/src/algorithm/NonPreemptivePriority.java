package algorithm;

import data.GanttEntry;
import data.Process;
import data.ScheduleResult;

// Non-Preemptive Priority Scheduling
// When the CPU is free, pick the process with the highest priority (lowest number).
// Once a process starts, it runs to full completion — it cannot be interrupted.
// Strength  : Simple, useful for real-time and embedded systems
// Weakness  : Low priority processes can starve if high priority ones keep arriving
// Real fix  : Aging — gradually raise priority of waiting processes over time
public class NonPreemptivePriority {

    public static ScheduleResult run(Process[] original, int count) {

        // Work on copies so original data stays unchanged
        Process[] processes = new Process[count];
        for (int i = 0; i < count; i++) {
            processes[i] = original[i].copy();
        }

        GanttEntry[] gantt = new GanttEntry[500];
        int ganttSize = 0;

        boolean[] done  = new boolean[count];
        int currentTime = 0;
        int completed   = 0;

        while (completed < count) {

            // Find the highest priority process that has arrived
            // Lower priority number = higher importance
            int selected         = -1;
            int highestPriority  = Integer.MAX_VALUE;

            for (int i = 0; i < count; i++) {
                if (!done[i] && processes[i].arrivalTime <= currentTime) {

                    if (processes[i].priority < highestPriority) {
                        highestPriority = processes[i].priority;
                        selected        = i;
                    }
                    // Tie-break: if same priority, pick the one that arrived first
                    else if (processes[i].priority == highestPriority && selected != -1) {
                        if (processes[i].arrivalTime < processes[selected].arrivalTime) {
                            selected = i;
                        }
                    }
                }
            }

            // No process available — jump to next arrival
            if (selected == -1) {
                int nextArrival = Integer.MAX_VALUE;
                for (int i = 0; i < count; i++) {
                    if (!done[i] && processes[i].arrivalTime < nextArrival) {
                        nextArrival = processes[i].arrivalTime;
                    }
                }
                currentTime = nextArrival;
                continue;
            }

            Process p = processes[selected];

            // Record start time
            p.startTime = currentTime;
            p.started   = true;

            // Non-preemptive — run the full burst time without interruption
            int sliceStart  = currentTime;
            currentTime    += p.burstTime;
            p.remainingTime = 0;
            p.finishTime    = currentTime;
            done[selected]  = true;
            completed++;

            gantt[ganttSize++] = new GanttEntry(p.pid, sliceStart, currentTime);
        }

        return new ScheduleResult(gantt, ganttSize, processes, count);
    }
}


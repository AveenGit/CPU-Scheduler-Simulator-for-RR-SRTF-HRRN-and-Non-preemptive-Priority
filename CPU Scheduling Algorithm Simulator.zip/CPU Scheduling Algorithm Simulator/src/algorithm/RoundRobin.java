package algorithm;

import data.GanttEntry;
import data.Process;
import data.ScheduleResult;

// Round Robin (RR) — Preemptive
// Each process gets a fixed time slice called the quantum.
// If a process doesn't finish in time, it goes back to the end of the queue.
// This keeps cycling until all processes are done.
// Strength : Fair — no starvation, good response time
// Weakness : Too many context switches if quantum is too small
public class RoundRobin {

    public static ScheduleResult run(Process[] original, int count, int quantum) {

        // Work on copies so the original user input stays unchanged
        Process[] processes = new Process[count];
        for (int i = 0; i < count; i++) {
            processes[i] = original[i].copy();
        }

        // Gantt chart can have at most count*burstTime blocks
        GanttEntry[] gantt = new GanttEntry[500];
        int ganttSize = 0;

        // Ready queue — stores indexes of processes waiting for CPU
        int[] queue    = new int[500];
        int queueFront = 0;
        int queueRear  = 0;

        boolean[] inQueue = new boolean[count]; // tracks if process is already in queue
        int currentTime   = 0;
        int completed     = 0;

        // Add all processes that arrive at time 0
        for (int i = 0; i < count; i++) {
            if (processes[i].arrivalTime == 0) {
                queue[queueRear++] = i;
                inQueue[i] = true;
            }
        }

        while (completed < count) {

            // If queue is empty, jump time forward to next arriving process
            if (queueFront == queueRear) {
                int nextArrival = Integer.MAX_VALUE;
                for (int i = 0; i < count; i++) {
                    if (!inQueue[i] && processes[i].remainingTime > 0) {
                        if (processes[i].arrivalTime < nextArrival) {
                            nextArrival = processes[i].arrivalTime;
                        }
                    }
                }
                currentTime = nextArrival;

                // Add all processes that have now arrived
                for (int i = 0; i < count; i++) {
                    if (!inQueue[i] && processes[i].arrivalTime <= currentTime && processes[i].remainingTime > 0) {
                        queue[queueRear++] = i;
                        inQueue[i] = true;
                    }
                }
                continue;
            }

            // Take the next process from the front of the queue
            int idx     = queue[queueFront++];
            Process p   = processes[idx];

            // Record start time the first time this process runs
            if (!p.started) {
                p.startTime = currentTime;
                p.started   = true;
            }

            // Run for quantum time, or whatever is left if less than quantum
            int runTime    = Math.min(quantum, p.remainingTime);
            int sliceStart = currentTime;

            currentTime      += runTime;
            p.remainingTime  -= runTime;

            // Check if any new processes arrived during this time slice
            for (int i = 0; i < count; i++) {
                if (!inQueue[i] && processes[i].arrivalTime <= currentTime && processes[i].remainingTime > 0) {
                    queue[queueRear++] = i;
                    inQueue[i] = true;
                }
            }

            // Record this block in the Gantt chart
            gantt[ganttSize++] = new GanttEntry(p.pid, sliceStart, currentTime);

            if (p.remainingTime == 0) {
                // Process finished
                p.finishTime = currentTime;
                completed++;
            } else {
                // Process not done — put it back at the end of the queue
                queue[queueRear++] = idx;
            }
        }

        return new ScheduleResult(gantt, ganttSize, processes, count);
    }
}

package algorithm;

import data.GanttEntry;
import data.Process;
import data.ScheduleResult;

// Highest Response Ratio Next (HRRN) — Non-Preemptive
// When the CPU is free, calculate the response ratio for every ready process.
// The process with the highest ratio runs next to completion.
//
// Response Ratio = (Waiting Time + Burst Time) / Burst Time
//
// The longer a process waits, the higher its ratio becomes.
// This naturally prevents starvation — waiting processes always get their turn eventually.
// Strength : Fair, no starvation, balances short and long processes
// Weakness : Non-preemptive, needs burst time known in advance
public class HRRN {

    public static ScheduleResult run(Process[] original, int count) {

        // Work on copies so original data stays unchanged
        Process[] processes = new Process[count];
        for (int i = 0; i < count; i++) {
            processes[i] = original[i].copy();
        }

        GanttEntry[] gantt = new GanttEntry[500];
        int ganttSize = 0;

        boolean[] done  = new boolean[count];
        int currentTime = 0;
        int completed   = 0;

        while (completed < count) {

            // Find the process with the highest response ratio
            int    selected     = -1;
            double highestRatio = -1.0;

            for (int i = 0; i < count; i++) {
                if (!done[i] && processes[i].arrivalTime <= currentTime) {

                    int waitingTime = currentTime - processes[i].arrivalTime;

                    // Response Ratio formula — longer wait = higher ratio = gets picked sooner
                    double ratio = (double)(waitingTime + processes[i].burstTime) / processes[i].burstTime;

                    if (ratio > highestRatio) {
                        highestRatio = ratio;
                        selected     = i;
                    }
                }
            }

            // No process available — jump to the next arrival
            if (selected == -1) {
                int nextArrival = Integer.MAX_VALUE;
                for (int i = 0; i < count; i++) {
                    if (!done[i] && processes[i].arrivalTime < nextArrival) {
                        nextArrival = processes[i].arrivalTime;
                    }
                }
                currentTime = nextArrival;
                continue;
            }

            Process p = processes[selected];

            // Record start time
            p.startTime = currentTime;
            p.started   = true;

            // HRRN is non-preemptive — run the full burst time without interruption
            int sliceStart  = currentTime;
            currentTime    += p.burstTime;
            p.remainingTime = 0;
            p.finishTime    = currentTime;
            done[selected]  = true;
            completed++;

            gantt[ganttSize++] = new GanttEntry(p.pid, sliceStart, currentTime);
        }

        return new ScheduleResult(gantt, ganttSize, processes, count);
    }
}
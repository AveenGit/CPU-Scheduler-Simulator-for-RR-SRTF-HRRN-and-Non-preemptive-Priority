
import gui.MainFrame;

import javax.swing.*;

// Entry point — launches the application.
// SwingUtilities.invokeLater ensures the GUI is created on the correct thread.
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainFrame();
            }
        });
    }
}
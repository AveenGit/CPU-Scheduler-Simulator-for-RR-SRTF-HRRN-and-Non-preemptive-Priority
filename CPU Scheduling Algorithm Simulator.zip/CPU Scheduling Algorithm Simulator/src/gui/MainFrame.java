package gui;

import algorithm.HRRN;
import algorithm.NonPreemptivePriority;
import algorithm.RoundRobin;
import algorithm.SRTF;
import data.Process;
import data.ScheduleResult;

import javax.swing.*;
import java.awt.*;

// MainFrame — the main application window.
// LEFT side  = InputPanel  (user enters processes and picks algorithm)
// RIGHT side = output area  (Gantt chart on top, Results table below)
public class MainFrame extends JFrame {

    private InputPanel   inputPanel;
    private GanttPanel   ganttPanel;
    private ResultsPanel resultsPanel;

    public MainFrame() {
        setTitle("CPU Scheduling Simulator — CSF3213");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 680);
        setLocationRelativeTo(null); // open in center of screen
        setLayout(new BorderLayout(10, 10));

        // Build panels
        inputPanel   = new InputPanel(this);
        ganttPanel   = new GanttPanel();
        resultsPanel = new ResultsPanel();

        // Right side = Gantt chart (top) + Results table (bottom)
        JPanel outputPanel = new JPanel(new BorderLayout(0, 10));
        outputPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 10));

        // Gantt chart inside a horizontal scroll pane (chart can be wider than screen)
        JScrollPane ganttScroll = new JScrollPane(ganttPanel,
                JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        ganttScroll.setPreferredSize(new Dimension(760, 120));

        outputPanel.add(ganttScroll,  BorderLayout.NORTH);
        outputPanel.add(resultsPanel, BorderLayout.CENTER);

        add(inputPanel,   BorderLayout.WEST);
        add(outputPanel,  BorderLayout.CENTER);

        setVisible(true);
    }

    // Called when the user clicks "Run Algorithm" in InputPanel
    public void runAlgorithm() {

        Process[] processes  = inputPanel.getProcesses();
        int       count      = inputPanel.getProcessCount();
        String    algorithm  = inputPanel.getSelectedAlgorithm();

        // Need at least 2 processes to run
        if (count < 2) {
            JOptionPane.showMessageDialog(this,
                    "Please enter at least 2 processes.",
                    "Not enough processes",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        ScheduleResult result = null;

        // Run the selected algorithm
        if ("Round Robin (RR)".equals(algorithm)) {
            int quantum = inputPanel.getQuantum();
            if (quantum <= 0) {
                JOptionPane.showMessageDialog(this, "Quantum must be greater than 0.", "Invalid Quantum", JOptionPane.ERROR_MESSAGE);
                return;
            }
            result = RoundRobin.run(processes, count, quantum);

        } else if ("SRTF".equals(algorithm)) {
            result = SRTF.run(processes, count);

        } else if ("HRRN".equals(algorithm)) {
            result = HRRN.run(processes, count);

        } else if ("Non-Preemptive Priority".equals(algorithm)) {
            result = NonPreemptivePriority.run(processes, count);
        }

        // Send results to the output panels
        if (result != null) {
            ganttPanel.setGantt(result.gantt, result.ganttSize, result.processes, result.processCount);
            resultsPanel.setResults(result);
        }
    }

    // Called when the user clicks "Clear All" in InputPanel
    public void clearOutput() {
        ganttPanel.clear();
        resultsPanel.clear();
    }
}


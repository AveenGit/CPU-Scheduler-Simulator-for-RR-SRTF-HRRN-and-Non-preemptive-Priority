package gui;

import data.Process;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// InputPanel — the LEFT side of the screen.
// User enters process details here, picks an algorithm, and clicks Run.
public class InputPanel extends JPanel {

    // Input fields
    private JTextField pidField;
    private JTextField arrivalField;
    private JTextField burstField;
    private JTextField priorityField;
    private JTextField quantumField;

    // Priority and quantum labels — shown/hidden depending on algorithm selected
    private JLabel priorityLabel;
    private JLabel quantumLabel;

    // Algorithm dropdown
    private JComboBox<String> algorithmBox;

    // Table showing all processes entered so far
    private JTable processTable;
    private DefaultTableModel tableModel;

    // Process storage — plain array, max 20
    private Process[] processes = new Process[20];
    private int processCount    = 0;

    // Reference to MainFrame so we can trigger the Run action from here
    private MainFrame mainFrame;

    public InputPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;

        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createTitledBorder("Process Input"));
        setBackground(new Color(248, 248, 248));
        setPreferredSize(new Dimension(300, 600));

        add(buildFieldsSection(),    BorderLayout.NORTH);
        add(buildTableSection(),     BorderLayout.CENTER);
        add(buildAlgorithmSection(), BorderLayout.SOUTH);
    }

    // -------------------------------------------------------------------------
    // TOP SECTION — input fields for one process
    // -------------------------------------------------------------------------
    private JPanel buildFieldsSection() {

        JPanel panel = new JPanel(new GridLayout(7, 2, 6, 6));
        panel.setBackground(new Color(248, 248, 248));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        pidField      = new JTextField();
        arrivalField  = new JTextField();
        burstField    = new JTextField();
        priorityField = new JTextField();
        quantumField  = new JTextField("3");

        // Priority row — hidden by default, only shown for NP Priority
        priorityLabel = new JLabel("Priority:");
        priorityLabel.setVisible(false);
        priorityField.setVisible(false);

        // Quantum row — shown by default (RR is default selection)
        quantumLabel = new JLabel("RR Quantum:");

        panel.add(new JLabel("PID:"));       panel.add(pidField);
        panel.add(new JLabel("Arrival:"));   panel.add(arrivalField);
        panel.add(new JLabel("Burst:"));     panel.add(burstField);
        panel.add(priorityLabel);            panel.add(priorityField);
        panel.add(quantumLabel);             panel.add(quantumField);

        // Add Process button
        JButton addBtn = new JButton("Add Process");
        addBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addProcess();
            }
        });

        // Clear All button
        JButton clearBtn = new JButton("Clear All");
        clearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearAll();
            }
        });

        panel.add(addBtn);
        panel.add(clearBtn);

        return panel;
    }

    // -------------------------------------------------------------------------
    // MIDDLE SECTION — table showing entered processes
    // -------------------------------------------------------------------------
    private JPanel buildTableSection() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(248, 248, 248));

        // Start with 3 columns — Priority column added only for NP Priority
        tableModel = new DefaultTableModel(new String[]{"PID", "Arrival", "Burst"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        processTable = new JTable(tableModel);
        processTable.setRowHeight(24);
        processTable.setFont(new Font("SansSerif", Font.PLAIN, 13));
        processTable.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));

        JScrollPane scroll = new JScrollPane(processTable);
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // -------------------------------------------------------------------------
    // BOTTOM SECTION — algorithm selector and Run button
    // -------------------------------------------------------------------------
    private JPanel buildAlgorithmSection() {

        JPanel panel = new JPanel(new GridLayout(3, 1, 6, 6));
        panel.setBackground(new Color(248, 248, 248));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        algorithmBox = new JComboBox<>(new String[]{
                "Round Robin (RR)",
                "SRTF",
                "HRRN",
                "Non-Preemptive Priority"
        });
        algorithmBox.setFont(new Font("SansSerif", Font.PLAIN, 13));

        // When algorithm changes, show or hide relevant fields
        algorithmBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateFieldVisibility();
            }
        });

        JButton runBtn = new JButton("Run Algorithm");
        runBtn.setFont(new Font("SansSerif", Font.BOLD, 13));
        runBtn.setBackground(new Color(70, 130, 200));
        runBtn.setForeground(Color.WHITE);
        runBtn.setFocusPainted(false);
        runBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mainFrame.runAlgorithm();
            }
        });

        panel.add(new JLabel("Select Algorithm:"));
        panel.add(algorithmBox);
        panel.add(runBtn);

        return panel;
    }

    // -------------------------------------------------------------------------
    // Shows Priority field only for NP Priority.
    // Shows Quantum field only for Round Robin.
    // Clears entered data if switching away from NP Priority
    // (because priority column would be inconsistent).
    // -------------------------------------------------------------------------
    private void updateFieldVisibility() {

        String selected   = (String) algorithmBox.getSelectedItem();
        boolean isRR      = "Round Robin (RR)".equals(selected);
        boolean isPriority = "Non-Preemptive Priority".equals(selected);

        priorityLabel.setVisible(isPriority);
        priorityField.setVisible(isPriority);
        quantumLabel.setVisible(isRR);
        quantumField.setVisible(isRR);

        // Add or remove the Priority column from the table
        if (isPriority && tableModel.getColumnCount() == 3) {
            tableModel.addColumn("Priority");
        } else if (!isPriority && tableModel.getColumnCount() == 4) {
            // Rebuild table with 3 columns and clear data
            processCount = 0;
            processes    = new Process[20];
            tableModel.setRowCount(0);
            tableModel.setColumnCount(3);
        }

        revalidate();
        repaint();
    }

    // -------------------------------------------------------------------------
    // Reads the input fields, validates them, and adds the process
    // -------------------------------------------------------------------------
    private void addProcess() {
        try {
            String pid   = pidField.getText().trim();
            int arrival  = Integer.parseInt(arrivalField.getText().trim());
            int burst    = Integer.parseInt(burstField.getText().trim());
            int priority = 0;

            // Only read priority if the NP Priority algorithm is selected
            if (priorityField.isVisible()) {
                String pText = priorityField.getText().trim();
                if (pText.isEmpty()) {
                    showError("Priority cannot be empty.");
                    return;
                }
                priority = Integer.parseInt(pText);
            }

            // --- Validation ---
            if (pid.isEmpty())  { showError("PID cannot be empty.");                    return; }
            if (burst <= 0)     { showError("Burst time must be greater than 0.");      return; }
            if (arrival < 0)    { showError("Arrival time cannot be negative.");        return; }
            if (processCount >= 20) { showError("Maximum 20 processes allowed.");       return; }

            // No duplicate PIDs
            for (int i = 0; i < processCount; i++) {
                if (processes[i].pid.equals(pid)) {
                    showError("PID '" + pid + "' already exists.");
                    return;
                }
            }

            // Store the process
            processes[processCount++] = new Process(pid, arrival, burst, priority);

            // Add to table
            if (priorityField.isVisible()) {
                tableModel.addRow(new Object[]{pid, arrival, burst, priority});
            } else {
                tableModel.addRow(new Object[]{pid, arrival, burst});
            }

            // Clear fields for next entry
            pidField.setText("");
            arrivalField.setText("");
            burstField.setText("");
            priorityField.setText("");
            pidField.requestFocus();

        } catch (NumberFormatException ex) {
            showError("Arrival, Burst, and Priority must be whole numbers.");
        }
    }

    // -------------------------------------------------------------------------
    // Clears all entered data
    // -------------------------------------------------------------------------
    private void clearAll() {
        processCount = 0;
        processes    = new Process[20];
        tableModel.setRowCount(0);
        mainFrame.clearOutput();
    }

    // -------------------------------------------------------------------------
    // Getters — used by MainFrame when running the algorithm
    // -------------------------------------------------------------------------
    public Process[] getProcesses()    { return processes;    }
    public int       getProcessCount() { return processCount; }
    public String    getSelectedAlgorithm() { return (String) algorithmBox.getSelectedItem(); }

    public int getQuantum() {
        try {
            return Integer.parseInt(quantumField.getText().trim());
        } catch (NumberFormatException e) {
            return 3; // default quantum if field is invalid
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }
}

package gui;

import data.ScheduleResult;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

// ResultsPanel — shows the per-process metrics table and summary averages.
// Sits below the Gantt chart on the right side of the screen.
public class ResultsPanel extends JPanel {

    private JTable           table;
    private DefaultTableModel tableModel;

    // Summary labels at the bottom
    private JLabel avgWTLabel;
    private JLabel avgTATLabel;
    private JLabel avgRTLabel;
    private JLabel throughputLabel;

    public ResultsPanel() {
        setLayout(new BorderLayout(0, 8));
        setBorder(BorderFactory.createTitledBorder("Results"));
        setBackground(Color.WHITE);

        add(buildTable(),   BorderLayout.CENTER);
        add(buildSummary(), BorderLayout.SOUTH);
    }

    // Table showing one row per process
    private JScrollPane buildTable() {
        String[] columns = {"PID", "Arrival", "Burst", "Priority", "Start", "Finish", "WT", "TAT", "RT"};

        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; } // read-only
        };

        table = new JTable(tableModel);
        table.setRowHeight(24);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));
        table.setGridColor(new Color(220, 220, 220));

        return new JScrollPane(table);
    }

    // Summary panel showing averages and throughput
    private JPanel buildSummary() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        panel.setBackground(new Color(197, 197, 234));
        panel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));

        Font f = new Font("SansSerif", Font.BOLD, 13);

        avgWTLabel      = new JLabel("Avg WT: —");
        avgTATLabel     = new JLabel("Avg TAT: —");
        avgRTLabel      = new JLabel("Avg RT: —");
        throughputLabel = new JLabel("Throughput: —");

        avgWTLabel.setFont(f);
        avgTATLabel.setFont(f);
        avgRTLabel.setFont(f);
        throughputLabel.setFont(f);

        panel.add(avgWTLabel);
        panel.add(avgTATLabel);
        panel.add(avgRTLabel);
        panel.add(throughputLabel);

        return panel;
    }

    // Fills the table and summary after an algorithm runs
    public void setResults(ScheduleResult result) {
        tableModel.setRowCount(0); // clear old results

        for (int i = 0; i < result.processCount; i++) {
            var p = result.processes[i];
            tableModel.addRow(new Object[]{
                    p.pid,
                    p.arrivalTime,
                    p.burstTime,
                    p.priority,
                    p.startTime,
                    p.finishTime,
                    p.getWaitingTime(),
                    p.getTurnaroundTime(),
                    p.getResponseTime()
            });
        }

        avgWTLabel.setText(String.format("Avg WT: %.2f",        result.getAverageWaitingTime()));
        avgTATLabel.setText(String.format("Avg TAT: %.2f",      result.getAverageTurnaroundTime()));
        avgRTLabel.setText(String.format("Avg RT: %.2f",        result.getAverageResponseTime()));
        throughputLabel.setText(String.format("Throughput: %.4f proc/unit", result.getThroughput()));
    }

    // Resets table and labels back to empty state
    public void clear() {
        tableModel.setRowCount(0);
        avgWTLabel.setText("Avg WT: —");
        avgTATLabel.setText("Avg TAT: —");
        avgRTLabel.setText("Avg RT: —");
        throughputLabel.setText("Throughput: —");
    }
}


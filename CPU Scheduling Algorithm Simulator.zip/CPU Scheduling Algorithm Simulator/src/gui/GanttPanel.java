package gui;

import data.GanttEntry;
import data.Process;

import javax.swing.*;
import java.awt.*;

// GanttPanel — draws the Gantt chart as colored blocks with time ticks below.
// Each process gets a fixed color. Blocks are drawn left to right.
public class GanttPanel extends JPanel {

    private GanttEntry[] gantt;     // The blocks to draw
    private int ganttSize;          // How many blocks exist

    private static final int BLOCK_WIDTH  = 50;  // pixels per time unit
    private static final int BLOCK_HEIGHT = 40;  // height of each block
    private static final int TOP_MARGIN   = 20;  // space above the blocks
    private static final int LEFT_MARGIN  = 20;  // space to the left

    // Fixed colors for up to 10 processes
    private static final Color[] COLORS = {
            new Color(144, 176, 240),
            new Color(144, 220, 180),
            new Color(255, 190, 120),
            new Color(220, 150, 200),
            new Color(150, 210, 210),
            new Color(255, 220, 130),
            new Color(200, 160, 220),
            new Color(180, 220, 140),
            new Color(240, 160, 160),
            new Color(160, 200, 240),
    };

    // Maps each PID to a color index — assigned in the order processes appear
    private String[] pidColorKeys   = new String[20];
    private int[]    pidColorValues = new int[20];
    private int      pidColorCount  = 0;

    public GanttPanel() {
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createTitledBorder("Gantt Chart"));
    }

    // Called after algorithm runs — updates chart data and redraws
    public void setGantt(GanttEntry[] gantt, int ganttSize, Process[] processes, int processCount) {
        this.gantt     = gantt;
        this.ganttSize = ganttSize;

        // Assign colors to each process in order of first appearance
        pidColorCount = 0;
        for (int i = 0; i < processCount; i++) {
            pidColorKeys[pidColorCount]   = processes[i].pid;
            pidColorValues[pidColorCount] = i % COLORS.length;
            pidColorCount++;
        }

        // Calculate how wide the panel needs to be based on total time
        int totalTime = (ganttSize > 0) ? gantt[ganttSize - 1].endTime : 0;
        int width = LEFT_MARGIN * 2 + totalTime * BLOCK_WIDTH + 60;
        setPreferredSize(new Dimension(width, TOP_MARGIN + BLOCK_HEIGHT + 40));
        revalidate();
        repaint();
    }

    // Clears the chart
    public void clear() {
        gantt     = null;
        ganttSize = 0;
        repaint();
    }

    // Returns the color assigned to a given PID
    private Color getColorForPid(String pid) {
        for (int i = 0; i < pidColorCount; i++) {
            if (pidColorKeys[i].equals(pid)) {
                return COLORS[pidColorValues[i]];
            }
        }
        return Color.LIGHT_GRAY; // fallback
    }

    // Swing calls this automatically whenever repaint() is triggered
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (gantt == null || ganttSize == 0) return;

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (int i = 0; i < ganttSize; i++) {
            GanttEntry entry = gantt[i];

            int x     = LEFT_MARGIN + entry.startTime * BLOCK_WIDTH;
            int width = (entry.endTime - entry.startTime) * BLOCK_WIDTH;

            // Draw filled block
            g2.setColor(getColorForPid(entry.pid));
            g2.fillRect(x, TOP_MARGIN, width, BLOCK_HEIGHT);

            // Draw block border
            g2.setColor(Color.DARK_GRAY);
            g2.drawRect(x, TOP_MARGIN, width, BLOCK_HEIGHT);

            // Draw process label centered inside the block
            g2.setFont(new Font("SansSerif", Font.BOLD, 13));
            FontMetrics fm  = g2.getFontMetrics();
            int textX = x + (width - fm.stringWidth(entry.pid)) / 2;
            int textY = TOP_MARGIN + BLOCK_HEIGHT / 2 + fm.getAscent() / 2 - 2;
            g2.setColor(Color.BLACK);
            g2.drawString(entry.pid, textX, textY);

            // Draw start time tick below the block
            g2.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g2.setColor(Color.DARK_GRAY);
            g2.drawString(String.valueOf(entry.startTime), x, TOP_MARGIN + BLOCK_HEIGHT + 15);
        }

        // Draw the final end time
        if (ganttSize > 0) {
            int finalX = LEFT_MARGIN + gantt[ganttSize - 1].endTime * BLOCK_WIDTH;
            g.setFont(new Font("SansSerif", Font.PLAIN, 11));
            g.setColor(Color.DARK_GRAY);
            g.drawString(String.valueOf(gantt[ganttSize - 1].endTime), finalX, TOP_MARGIN + BLOCK_HEIGHT + 15);
        }
    }
}
